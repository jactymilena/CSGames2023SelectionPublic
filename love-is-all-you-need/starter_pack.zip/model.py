import numpy as np

class Model:
    def __init__(self):

        self.model = None

    def train(self, X, Y):
        """
        X: (N) matrix containing training data
        Y: (N) matrix containing training labels

        Returns: The trained model
        """
        return None

    def predict(self, X):
        """
        model : Your trained model
        text : Text to predict the class

        Returns: the class prediction
        """

        return 0


