from model import Model
import numpy as np
import csv
import json

def load_data():
    """
    Load data from CSV files
    Of course, test labels aren't included ;)

    You should not modify this function
    """

    training_data = []
    training_label = []
    test_data = []

    with open('Data/train_data.csv', encoding='latin1') as csvfile:
         spamreader = csv.reader(csvfile, delimiter='\n', quotechar='"')
         for row in spamreader:
            training_data.append(row)

    with open('Data/test_data.csv', encoding='latin1') as csvfile:
         spamreader = csv.reader(csvfile, delimiter='\n', quotechar='"')
         for row in spamreader:
            test_data.append(row)

    with open('Data/train_label.csv', encoding='latin1') as csvfile:
         spamreader = csv.reader(csvfile, delimiter='\n', quotechar='"')
         for row in spamreader:
            training_label.append(row)

    return np.array(training_data), np.array(training_label), np.array(test_data)


def get_predictions(test_data, model):
    """
    Summary: Get predictions into a (N,) vector to be later saved to a CSV file

    You should not modify this function
    """
    predictions = model.predict(test_data)

    return predictions

def save_predictions(predictions):
    """
    Save predictions to a CSV file so they can be evaluated

    You should not modify this function
    """
    str_pred = [str(i) for i in predictions]
    with open('Data/predictions.json', 'w') as outfile:
        json.dump(str_pred, outfile)

def main():
    """
    Load data, then train the model, then get predictions from test data"

    You should not modify this function
    """

    print('Loading data')
    training_data, training_label, test_data = load_data()

    model = Model()

    print('Start training')
    model.train(training_data[:, 0], training_label[:, 0])

    print('Start testing')
    predictions = get_predictions(test_data[:, 0], model)

    print('Saving predictions')
    save_predictions(predictions)

if __name__ == "__main__":
    main()

